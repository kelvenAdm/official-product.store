<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CarboFix - Official - Today Only $49/Bottle</title>

    <link rel="icon" href="img/favicon.png?v=1665068493">

    <meta name='keywords' content='CarboFix, CarboFix Supplement'>
    <meta name='description' content='CarboFix is a natural supplement. Buy Today 50% Off'>
    <meta http-equiv='content-language' content='en-us'>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css?v=1665068493">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@400;500;600&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">

    <script src="js/jquery-3.5.1.min.js"></script>

<script type="text/javascript">
    (function(c,l,a,r,i,t,y){
        c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
        t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
        y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
    })(window, document, "clarity", "script", "d5i2cvtjlo");
</script>

<!-- Global site tag (gtag.js) - Google Ads: 10991190578 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-10991190578"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-10991190578');
  gtag('config', 'G-WZKXG53BG9');
</script>


</head>
<body>
    <nav id="navbar">
        <div class="container">
            <div class="nav-logo">
                <span class="logo">Discover The Secret Of CarboFix</span>
            </div>
        </div>
    </nav>

    <header id="header">
        <div class="container grid">
            <div class="header-left">
                <div class="header-img">
                    <a href="order-now"><img style="width: 78%;" src="img/bottles-header.png?v=1665068493" alt="CarboFix"></a>
                </div>
		<div class="header-timer-title">
                    <h2><span>Hurry Up!</span><br> Last Units</h2>
                </div>
            </div>

            <div class="header-right">
                <h2>Attention! Get Special Discount Today</h2>
                <ul>
                    <li><i class="fas fa-check"></i>No Side Effects</li>
 		    <li><i class="fas fa-check"></i>Increases fat-burning</li>
                    <li><i class="fas fa-check"></i>Increases weight loss</li>
                </ul>

                <div class="header-buy">

                    <div class="btn-wrapper">
                        <button onclick="location.href='order-now/'" class="btn3">Access Official Website</button>
                    </div>
                    <img src="img/fda.png?v=1665068493" alt="CarboFix Supplement">
                </div>
            </div>
        </div>
    </header>




    <footer id="footer">
        <div class="container">
            <div class="footer-links">
                <a href="terms-of-use.html">TOS</a>
                <a href="privacy-policy.html">Privacy</a>
                <a href="disclaimer.html">Disclaimer</a>
                <a href="order-now">Contact</a>
            </div>
            </div>
            <div id="footer-copyright">
                <p>© Copyright 2022 Bestbuyfor.me All Rights Reserved.</p>
            </div>
        </div>
    </footer>

</body>

</html>
